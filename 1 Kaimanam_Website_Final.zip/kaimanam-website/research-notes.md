# Kai Manam — research notes

Checked 28 Oct 2026. Public sources used for the website concept:

- Live Chennai (22 Dec 2025): Kai Manam began as a terrace kitchen in Gopalapuram, was founded by former radio jockey Vishnu Priya, and opened a second outlet on ECR. The article reports growth from 1,725 yearly orders in 2020 to 44,680 through Nov 2025 and 20+ staff.
- Zomato Gopalapuram: 15, Gopalapuram 1st Street; phone +91 91506 10191; listed hours 11am–4pm and 6pm–12 midnight; approx ₹600 for two; cuisines include South Indian, Chettinad, Biryani, Seafood and more.
- Zomato Akkarai: Door 23, SPR Food Court, Kalaignar Karunanidhi Salai, Akkarai, Chennai; phone +91 98419 69723; listed hours 12 noon–12 midnight.
- Swiggy Gopalapuram: current public listing shows South Indian/Chettinad and dishes including Chicken Chukka, Mutton Chukka, Prawn Thokku, Chicken 65, Poricha Kozhi, Chicken Curry Dosa and more.
- Magicpin: current public listing contains a broader menu and online prices; prices can differ by platform/outlet/offer.
- Hotelier India: public photo of the ECR outlet signboard.

Important: this is a design concept, not an official Kai Manam website. Confirm all hours, phone numbers, menu, prices, social handles, claims and image rights before publishing.
