# Kai Manam — Website concept

A responsive, single-page restaurant website concept built with plain HTML, CSS and JavaScript. No build step or framework is required.

## Preview locally

Open `index.html` in a current browser. Internet access is needed for the externally hosted restaurant photos and Google Fonts.

## Included features

- Responsive layout and mobile navigation
- Brand story based on public reporting
- Filterable sample menu
- Current online-menu price examples with an explicit price disclaimer
- Swiggy, Zomato, Instagram, WhatsApp, telephone and map links
- Two location cards for Gopalapuram and the ECR/Akkarai outlet
- Accessibility features including skip link, keyboard-friendly controls and reduced-motion support

## Before launch

This is a design concept, not an officially approved or live business website. Confirm the correct brand name, contact numbers, menu, outlet hours, branch details, social handle and ordering links with Kai Manam. The photos currently load from public Zomato, Swiggy and press-coverage URLs; check rights and hotlinking terms before production use. Ideally ask the restaurant for original food, restaurant, founder and logo assets and host approved files on the final website domain. Replace all example prices with the current official menu.

## Files

- `index.html` — complete website
- `assets/kaimanam-profile-logo.jpg` — cropped from the profile screenshot provided in this conversation for concept/mock-up use
- `research-notes.md` — research findings and source URLs
- `photo-sources.md` — individual remote-image sources and usage cautions
