# Photo sources

The current concept uses public image URLs as visual references. For a commercial launch, request original high-resolution assets and permission from Kai Manam.

1. Chicken Chukka — Swiggy listing image
https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy%2Cf_auto%2Cq_auto/FOOD_CATALOG/IMAGES/CMS/2024/11/28/cbfa543e-8619-4638-a780-8c17fa5e3f65_9b1955eb-b590-4c1d-a768-1b6e01c406ea.jpg
2. Prawn Fried Rice — Zomato
https://b.zmtcdn.com/data/pictures/chains/6/19416476/fe1bcc8f1ad5f2a9e435792236137dac.jpg
3. ECR outlet signboard — Hotelier India
https://www.hotelierindia.com/cloud/2025/12/19/WhatsApp-Image-2025-12-19-at-10.57.26-AM.jpeg
4. Akkarai interior — Zomato
https://b.zmtcdn.com/data/pictures/4/22288144/8d3f5b90c517735a525395d30d0342eb.jpg
